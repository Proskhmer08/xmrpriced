async function updatePopup() {
  const errorEl = document.getElementById('error');
  let rpcSuccess = false;
  let endpointUsed = '';

  try {
    // Fetch XMR/USD price
    const priceRes = await fetch('https://api.coingecko.com/api/v3/simple/price?ids=monero&vs_currencies=usd');
    if (!priceRes.ok) throw new Error('Price fetch failed');
    const priceData = await priceRes.json();
    const rate = priceData.monero.usd || 351;
    document.getElementById('rate').textContent = `1 XMR = $${rate.toFixed(2)}`;

    // UTC timestamp
    const now = new Date();
    const utcTime = now.toUTCString();
    document.getElementById('timestamp').textContent = `Updated: ${utcTime}`;

    // Web-compatible RPC endpoints
    const rpcEndpoints = [
      'https://node.sethforprivacy.com/json_rpc',
      'https://xmr.cryptostorm.is:18081/json_rpc',
      'https://public-monero-node.xyz/json_rpc',
      'https://xmr.0xrpc.io/json_rpc'
    ];

    let info = {};
    let txCount = '—';

    // Try endpoints for get_info
    for (const endpoint of rpcEndpoints) {
      try {
        const rpcRes = await fetch(endpoint, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            jsonrpc: '2.0',
            id: '0',
            method: 'get_info'
          })
        });

        if (!rpcRes.ok) continue;

        const rpcData = await rpcRes.json();
        if (rpcData.error || !rpcData.result) continue;

        info = rpcData.result;
        endpointUsed = endpoint;
        rpcSuccess = true;
        break;
      } catch (e) {}
    }

    if (!rpcSuccess) throw new Error('All RPC endpoints failed for get_info');

    document.getElementById('height').textContent = info.height || '—';
    document.getElementById('difficulty').textContent = info.difficulty 
      ? `${(info.difficulty / 1e9).toFixed(2)} G` 
      : '—';

    const hashrateApprox = info.difficulty ? (info.difficulty / 120 / 1e9).toFixed(2) + ' GH/s' : '—';
    document.getElementById('hashrate').textContent = hashrateApprox;

    const dbSizeGB = info.database_size 
      ? `${(info.database_size / (1024 ** 3)).toFixed(1)} GB` 
      : '≈140–160 GB';
    document.getElementById('dbSize').textContent = dbSizeGB + ' (full node)';

    // Fetch tx count: try current height first, fallback to previous
    if (info.height && endpointUsed) {
      const targetHeight = info.height;
      for (let attempt = 0; attempt < 2; attempt++) {  // 0 = current, 1 = previous
        const heightToQuery = targetHeight - attempt;
        try {
          const blockRes = await fetch(endpointUsed, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              jsonrpc: '2.0',
              id: '0',
              method: 'get_block',
              params: { height: heightToQuery }
            })
          });

          if (blockRes.ok) {
            const blockData = await blockRes.json();
            if (blockData.result && blockData.result.block_header) {
              txCount = blockData.result.block_header.num_txes || 0;
              break;  // Success → stop
            }
          }
        } catch (blockErr) {
          console.warn(`get_block attempt ${attempt} failed for height ${heightToQuery}:`, blockErr);
        }
      }
    }

    const txElement = document.getElementById('txCount');
    if (txElement) {
      txElement.textContent = txCount;
    }

    errorEl.textContent = '';

  } catch (err) {
    console.error('Popup data fetch error:', err);
    errorEl.textContent = 'Unable to fetch live data from public nodes. Using fallback values.';
    document.getElementById('rate').textContent = '1 XMR ≈ $351';
    document.getElementById('timestamp').textContent = 'Fallback mode';
    document.getElementById('height').textContent = '—';
    document.getElementById('difficulty').textContent = '—';
    document.getElementById('hashrate').textContent = '—';
    document.getElementById('dbSize').textContent = '— (full node approx.)';
    const txElement = document.getElementById('txCount');
    if (txElement) txElement.textContent = '—';
  }
}

updatePopup();
setInterval(updatePopup, 60000);