let xmrRate = 351; // fallback; updated to approximate current value

async function fetchXMRRate() {
  try {
    const response = await fetch('https://api.coingecko.com/api/v3/simple/price?ids=monero&vs_currencies=usd');
    const data = await response.json();
    xmrRate = data.monero.usd || 351;
    console.log('XMR rate updated:', xmrRate);
  } catch (error) {
    console.log('Using fallback XMR rate:', xmrRate);
  }
}

function addXMRPrices() {
  if (!xmrRate) return;

  const priceSelectors = [
    '.a-price', '.a-offscreen', '.price', 'span[class*="price"]',
    'div[class*="price"]', '.a-price-whole', '.a-price-fraction',
    // Best Buy specific
    '.priceView-hero-price', '.pricing-container', '[data-automation-id="product-price"]',
    // Apple and general retail
    '.price', '.product-price', '[class*="price"]', 'span.price'
  ];

  document.querySelectorAll(priceSelectors.join(', ')).forEach(element => {
    // Skip if already processed or contains XMR
    if (element.querySelector('.xmr-converted') || element.textContent.includes('XMR')) return;

    // Apple.com specific limiter: only process elements inside known main price containers
    if (window.location.hostname.includes('apple.com')) {
      if (!element.closest('.price-point') && !element.closest('[data-testid="price"]')) return;
    }

    let text = element.textContent.trim();
    if (!text.includes('$')) return;

    const match = text.match(/\$([0-9,]+\.?[0-9]*)/);
    if (!match) return;

    const usd = parseFloat(match[1].replace(/,/g, ''));
    if (isNaN(usd) || usd < 1) return;

    const xmr = (usd / xmrRate).toFixed(5);

    const xmrSpan = document.createElement('span');
    xmrSpan.className = 'xmr-converted';
    xmrSpan.style.cssText = `
      margin-left: 6px;
      color: #FF6600;
      font-size: 0.85em;
      font-weight: normal;
      opacity: 0.85;
      vertical-align: baseline;
    `;
    xmrSpan.textContent = `(~${xmr} XMR)`;

    // Append at end to avoid breaking layout
    element.appendChild(xmrSpan);
  });
}

// Initialize and observe changes
fetchXMRRate().then(() => {
  addXMRPrices();
  const observer = new MutationObserver(addXMRPrices);
  observer.observe(document.body, { childList: true, subtree: true });
});